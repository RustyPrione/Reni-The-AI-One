Do the following commands in Powershell in windows 10 to activate Assitant

1.update pip installer to version 3 in powershell
2.make you check you have install Microsoft Visual C++ 14.0 is Required

then install following pacakges:

3.pip install speech_recognition
4.pip install pyaudio 
(NOTE:If you get error installing PyAudio please install using .WHL file using pip command)
(check out videos in youtube how install pyaudio using .whl file) 
5.pip install pygame
6.pip install pyttsx3
7.pip install selenium

Not mandatory make sure you check packages are installed:

8.pip install os
9.pip install time

Read fully the Command File to communicate with Reni.

**##Once everything is done Double click on Reni-The AI one(Start Here) file..##**

Note: Reni will provide webautomation services only on Mozilla Firefox
please make sure you have mozilla firefox on your system and check selenium package
is properly installed.
