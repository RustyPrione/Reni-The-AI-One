def systemdrivers(text):
    '''print("i am in ")'''
    import pyttsx3
    import os
    engine=pyttsx3.init()
    sound=engine.getProperty('voices')
    engine.setProperty('voice',sound[1].id)
    
    if(('Open C Drive'==text)|('show my C drive'==text)|('show me my C drive'==text)|(text=='open C drive')|(text=='Open C drive')|(text=='open c drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning C Drive of your Computer")
        engine.runAndWait()
        os.system("explorer C:")
        
    
    if((text=='open D drive')|(text=='Open D drive')|(text=='Open D Drive')|(text=='open d drive')|('show my D drive'==text)|('show me my D drive'==text)|('show my d drive'==text)|('show me my d drive'==text)):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning D Drive of your Computer")
        engine.runAndWait()
        os.system("explorer D:")
        
        
    if((text=='open E drive')|(text=='Open E drive')|(text=='Open E Drive')|(text=='open e drive')|('show my E drive'==text)|('show me my E drive'==text)|('show my e drive'==text)|('show me my e drive'==text)):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning E Drive of your Computer")
        engine.runAndWait()
        os.system("explorer E:")
        
    if((text=='open F drive')|(text=='Open F drive')|(text=='Open F Drive')|(text=='open f drive')|('show my F drive'==text)|('show me my F drive'==text)|('show my f drive'==text)|('show me my f drive'==text)):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning F Drive of your Computer")
        engine.runAndWait()
        print("g")
        os.system("explorer F:")
        
    if((text=='open G drive')|(text=='Open G drive')|(text=='Open G Drive')|(text=='open g drive')|('show my G drive'==text)|('show me my G drive'==text)|('show my g drive'==text)|('show me my g drive'==text)):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning G Drive of your Computer")
        engine.runAndWait()
        os.system("explorer G:")
      
        
    if((text=='open H drive')|(text=='Open H drive')|(text=='Open H Drive')|(text=='open h drive')|('show my H drive'==text)|('show me my H drive'==text)|('show my h drive'==text)|('show me my h drive'==text)):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning H Drive of your Computer")
        engine.runAndWait()
        os.system("explorer H:")
       
        
    if((text=='open I drive')|(text=='Open I drive')|(text=='Open I Drive')|(text=='open i drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning I Drive of your Computer")
        engine.runAndWait()
        os.system("explorer I:")
        
        
    if((text=='open J drive')|(text=='Open J drive')|(text=='Open J Drive')|(text=='open j drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning J Drive of your Computer")
        engine.runAndWait()
        os.system("explorer J:")
       
        
    if((text=='open K drive')|(text=='Open K drive')|(text=='Open K Drive')|(text=='open k drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning K Drive of your Computer")
        engine.runAndWait()
        os.system("explorer D:")
       

    if((text=='open L drive')|(text=='Open L drive')|(text=='Open L Drive')|(text=='open l drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning L Drive of your Computer")
        engine.runAndWait()
        os.system("explorer L:")
       
        
    if((text=='open M drive')|(text=='Open M drive')|(text=='Open M Drive')|(text=='open m drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning M Drive of your Computer")
        engine.runAndWait()
        os.system("explorer M:")
       
        
    if((text=='open N drive')|(text=='Open N drive')|(text=='Open N Drive')|(text=='open n drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning N Drive of your Computer")
        engine.runAndWait()
        os.system("explorer N:")
   
        
    if((text=='open O drive')|(text=='Open O drive')|(text=='Open O Drive')|(text=='open o drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning O Drive of your Computer")
        engine.runAndWait()
        os.system("explorer O:")
    
        
    if((text=='open P drive')|(text=='Open P drive')|(text=='Open P Drive')|(text=='open p drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning P Drive of your Computer")
        engine.runAndWait()
        os.system("explorer P:")
        
        
    if((text=='open Q drive')|(text=='Open Q drive')|(text=='Open Q Drive')|(text=='open q drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning Q Drive of your Computer")
        engine.runAndWait()
        os.system("explorer Q:")
       

    if((text=='open R drive')|(text=='Open R drive')|(text=='Open R Drive')|(text=='open r drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning R Drive of your Computer")
        engine.runAndWait()
        os.system("explorer R:")
       
        
    if((text=='open S drive')|(text=='Open S drive')|(text=='Open S Drive')|(text=='open s drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning S Drive of your Computer")
        engine.runAndWait()
        os.system("explorer S:")
        
        
    if((text=='open T drive')|(text=='Open T drive')|(text=='Open T Drive')|(text=='open t drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning T Drive of your Computer")
        engine.runAndWait()
        os.system("explorer T:")
        

        
    if((text=='open U drive')|(text=='Open U drive')|(text=='Open U Drive')|(text=='open u drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning U Drive of your Computer")
        engine.runAndWait()
        os.system("explorer U:")
   
        
    if((text=='open V drive')|(text=='Open V drive')|(text=='Open V Drive')|(text=='open v drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning V Drive of your Computer")
        engine.runAndWait()
        os.system("explorer V:")
        

    if((text=='open W drive')|(text=='Open W drive')|(text=='Open W Drive')|(text=='open w drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning W Drive of your Computer")
        engine.runAndWait()
        os.system("explorer W:")
      
        
    if((text=='open X drive')|(text=='Open X drive')|(text=='Open X Drive')|(text=='open x drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning X Drive of your Computer")
        engine.runAndWait()
        os.system("explorer X:")
        
        
    if((text=='open Y drive')|(text=='Open Y drive')|(text=='Open Y Drive')|(text=='open y drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning Y Drive of your Computer")
        engine.runAndWait()
        os.system("explorer Y:")
        
        
    if((text=='open Z drive')|(text=='Open Z drive')|(text=='Open Z Drive')|(text=='open z drive')):
        engine.say("Yep sure here you go.")
        engine.runAndWait()
        engine.say("Openning Z Drive of your Computer")
        engine.runAndWait()
        os.system("explorer Z:")
        
